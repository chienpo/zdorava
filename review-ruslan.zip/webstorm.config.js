// SystemJS aliases for WebStorm

/* global System */
System.config({
  paths: {
    '*': './src/*',
  },
});
