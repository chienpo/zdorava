import React from 'react'
import { Navigation } from './components/navigation';
import { RoutesContent } from './routes-content';

export const Layout = () => (
  <>
    <Navigation />
    <RoutesContent />
  </>
);
