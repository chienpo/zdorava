import { createElement } from 'react';
import { useRoute } from 'react-router5';
import { NavigationView } from './navigation-view';

export const Navigation = () => {
  const navLinks = [
    {
      label: 'Main',
      routeName: 'home',
    },
    {
      label: 'About',
      routeName: 'about',
    },
    {
      label: 'Portfolio',
      routeName: 'portfolio',
    },
  ];

  const { router } = useRoute();

  const theme = 'dark';

  return createElement(NavigationView, { router, navLinks, theme });
};
