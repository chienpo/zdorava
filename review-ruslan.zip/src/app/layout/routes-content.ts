import { createElement } from 'react';

import { Home } from '../features/home';
import { About } from '../features/about';
import { Portfolio } from '../features/portfolio';
import { useRouteNode } from 'react-router5';

export const RoutesContent: any = () => {
  const { route } = useRouteNode('');

  let topRouteName = route && route.name.split('.')[0];

  switch (topRouteName) {
    case 'home':
      return createElement(Home);
    case 'about':
      return createElement(About);
    case 'portfolio':
      return createElement(Portfolio);
    default:
      return null;
  }
};
