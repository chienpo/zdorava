import * as React from 'react';

export const PortfolioView = () => (
  <div>
    Portfolio
  </div>
);
