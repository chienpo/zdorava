import { createElement } from 'react';

import { HomeView } from './home-view';

export const Home = () => createElement(HomeView);
