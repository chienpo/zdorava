import * as React from 'react';

export const HomeView = () => (
  <div>
    Home
  </div>
);
