import { createElement } from 'react';

import { AboutView } from './about-view';

export const About = () => createElement(AboutView);
