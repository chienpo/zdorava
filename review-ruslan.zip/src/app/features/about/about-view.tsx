import * as React from 'react';

export const AboutView = () => (
  <div>
    About
  </div>
);
