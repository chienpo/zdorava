export type ClassName = {
  className?: string;
};
