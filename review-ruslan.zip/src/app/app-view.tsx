import React from 'react';
import { RouterProvider, BaseLink } from 'react-router5';

import Providers from './providers';
import { Layout } from './layout';

// App providers
export const AppView = ({ router }: any) => (
  <>
    <RouterProvider router={router} >
      <Providers>
        <BaseLink
          router={router}
          routeName="about"
          routeOptions={{ reload: true }}
        >asdasdasd</BaseLink>
        <Layout />
      </Providers>
    </RouterProvider>
  </>
);
