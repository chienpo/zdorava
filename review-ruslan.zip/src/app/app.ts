import { hot } from 'react-hot-loader';
import { AppView } from './app-view';

export const App = hot(module)(AppView);
