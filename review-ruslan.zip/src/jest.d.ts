declare namespace jest {
  interface Matchers<R> {
    toBeInTheDocument(): void;
  }
}
