export const routes = [
  { name: 'home', path: '/' },
  { name: 'about', path: '/about' },
  { name: 'portfolio', path: '/portfolio' },
];
